
import java.awt.Component;
import java.awt.HeadlessException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Random;
import javax.swing.JOptionPane;
import net.proteanit.sql.DbUtils;


public class MyPage extends javax.swing.JFrame {
Connection conn;
ResultSet rs;
PreparedStatement pst;
   
    public MyPage() {
        super("Home");
        initComponents();
        conn=javaconnect.ConnecrDb();
       showDate();
        Table1();
        RandomID();
        RandomID1();
        RandomID2();
    }
    
    public void RandomID(){
        Random ra=new Random();
        Tran_ID.setText(""+ra.nextInt(1000+1));
    }
    
    public void RandomID1(){
        Random ra=new Random();
        Tran_ID1.setText(""+ra.nextInt(1000+1));
    }
    
    public void RandomID2(){
        Random ra=new Random();
        Tran_ID2.setText(""+ra.nextInt(1000+1));
    }
    public void showDate()
        {
            Date d=new Date();
            SimpleDateFormat sf=new SimpleDateFormat("dd-MMM-yyyy");
            dte.setText(sf.format(d));  
        }
    
     public void Table1(){
        try{
          String sql="select C.Client_ID,A.ACCOUNTNO,C.NAME,A.ACC_TYPE,A.AMOUNT,C.MOB_NO From ACCOUNT A,CLIENT C WHERE C.CLIENT_ID=A.CLIENT_ID";
          pst=conn.prepareStatement(sql);
          rs=pst.executeQuery();
          jTable1.setModel(DbUtils.resultSetToTableModel(rs));
        }catch(SQLException e){
            JOptionPane.showMessageDialog(null, e);
        }finally{
            try{
                rs.close();
                pst.close();
            }catch(SQLException e){
               // JOptionPane.showMessageDialog(null, e);
            }
        }
    }
   
 
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        dte = new javax.swing.JTextField();
        jTabbedPane1 = new javax.swing.JTabbedPane();
        jPanel1 = new javax.swing.JPanel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        Name = new javax.swing.JTextField();
        DOB = new javax.swing.JTextField();
        Nationality = new javax.swing.JTextField();
        Gender = new javax.swing.JTextField();
        Address = new javax.swing.JTextField();
        jLabel10 = new javax.swing.JLabel();
        Religion = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        jLabel13 = new javax.swing.JLabel();
        Account_Type = new javax.swing.JTextField();
        religion = new javax.swing.JTextField();
        MobileNo = new javax.swing.JTextField();
        Sec_Q = new javax.swing.JTextField();
        jButton2 = new javax.swing.JButton();
        jButton3 = new javax.swing.JButton();
        jLabel19 = new javax.swing.JLabel();
        Sec_A = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        AccountNo = new javax.swing.JTextField();
        jButton1 = new javax.swing.JButton();
        jLabel27 = new javax.swing.JLabel();
        Job = new javax.swing.JTextField();
        jLabel28 = new javax.swing.JLabel();
        income = new javax.swing.JTextField();
        jLabel29 = new javax.swing.JLabel();
        Client_ID = new javax.swing.JTextField();
        jButton12 = new javax.swing.JButton();
        jPanel2 = new javax.swing.JPanel();
        jLabel15 = new javax.swing.JLabel();
        jLabel16 = new javax.swing.JLabel();
        jLabel17 = new javax.swing.JLabel();
        jLabel18 = new javax.swing.JLabel();
        Accno = new javax.swing.JTextField();
        name = new javax.swing.JTextField();
        Dep_amnt = new javax.swing.JTextField();
        Bal = new javax.swing.JTextField();
        jButton4 = new javax.swing.JButton();
        Total_amnt = new javax.swing.JTextField();
        tot = new javax.swing.JButton();
        jButton6 = new javax.swing.JButton();
        jLabel11 = new javax.swing.JLabel();
        type = new javax.swing.JComboBox<>();
        jLabel30 = new javax.swing.JLabel();
        Tran_ID = new javax.swing.JTextField();
        jPanel3 = new javax.swing.JPanel();
        jLabel21 = new javax.swing.JLabel();
        jLabel22 = new javax.swing.JLabel();
        jLabel23 = new javax.swing.JLabel();
        jLabel24 = new javax.swing.JLabel();
        jLabel25 = new javax.swing.JLabel();
        uaccno = new javax.swing.JTextField();
        uname = new javax.swing.JTextField();
        ubal = new javax.swing.JTextField();
        jButton7 = new javax.swing.JButton();
        Trans_amnt = new javax.swing.JTextField();
        total = new javax.swing.JTextField();
        jButton8 = new javax.swing.JButton();
        Credit_amnt = new javax.swing.JTextField();
        Cre_total = new javax.swing.JTextField();
        jButton9 = new javax.swing.JButton();
        jButton10 = new javax.swing.JButton();
        cname = new javax.swing.JTextField();
        jLabel20 = new javax.swing.JLabel();
        jLabel26 = new javax.swing.JLabel();
        caccno = new javax.swing.JTextField();
        jButton11 = new javax.swing.JButton();
        Tran_ID1 = new javax.swing.JTextField();
        jLabel31 = new javax.swing.JLabel();
        Tran_ID2 = new javax.swing.JTextField();
        jLabel32 = new javax.swing.JLabel();
        jPanel6 = new javax.swing.JPanel();
        jLabel14 = new javax.swing.JLabel();
        tacno = new javax.swing.JTextField();
        jButton5 = new javax.swing.JButton();
        jScrollPane2 = new javax.swing.JScrollPane();
        jTable2 = new javax.swing.JTable();
        jPanel7 = new javax.swing.JPanel();
        jLabel33 = new javax.swing.JLabel();
        jLabel34 = new javax.swing.JLabel();
        jLabel37 = new javax.swing.JLabel();
        baccno = new javax.swing.JTextField();
        bname = new javax.swing.JTextField();
        bbal = new javax.swing.JTextField();
        jButton14 = new javax.swing.JButton();
        jPanel5 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        newacc = new javax.swing.JButton();
        jLabel36 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel1.setIcon(new javax.swing.ImageIcon("C:\\Users\\HP\\Downloads\\Banking_Management_System-master\\images\\ll.jpg")); // NOI18N
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 10, -1, 136));

        jLabel3.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel3.setText("Date");
        getContentPane().add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(560, 40, 40, -1));

        dte.setEditable(false);
        dte.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        dte.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                dteActionPerformed(evt);
            }
        });
        getContentPane().add(dte, new org.netbeans.lib.awtextra.AbsoluteConstraints(610, 40, 144, 20));

        jTabbedPane1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(102, 0, 51), 2));
        jTabbedPane1.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N

        jPanel1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 51, 51), 2));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel4.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel4.setText("Name");
        jPanel1.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 110, 76, -1));

        jLabel5.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel5.setText("Date of Birth");
        jPanel1.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 170, -1, 20));

        jLabel6.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel6.setText("Nationality");
        jPanel1.add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 230, 76, -1));

        jLabel7.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel7.setText("Gender");
        jPanel1.add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 290, 76, -1));

        jLabel8.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel8.setText("Address");
        jPanel1.add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 350, 76, -1));

        Name.setEditable(false);
        Name.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jPanel1.add(Name, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 110, 190, 20));

        DOB.setEditable(false);
        DOB.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jPanel1.add(DOB, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 170, 190, 20));

        Nationality.setEditable(false);
        Nationality.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jPanel1.add(Nationality, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 230, 190, 20));

        Gender.setEditable(false);
        Gender.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jPanel1.add(Gender, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 290, 190, 20));

        Address.setEditable(false);
        Address.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jPanel1.add(Address, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 350, 190, 20));

        jLabel10.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel10.setText("Account Type");
        jPanel1.add(jLabel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(420, 110, 107, -1));

        Religion.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        Religion.setText("Religion");
        jPanel1.add(Religion, new org.netbeans.lib.awtextra.AbsoluteConstraints(420, 170, 107, -1));

        jLabel12.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel12.setText("Mobile");
        jPanel1.add(jLabel12, new org.netbeans.lib.awtextra.AbsoluteConstraints(420, 230, 107, -1));

        jLabel13.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel13.setText("Security Question");
        jPanel1.add(jLabel13, new org.netbeans.lib.awtextra.AbsoluteConstraints(420, 290, -1, -1));

        Account_Type.setEditable(false);
        Account_Type.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jPanel1.add(Account_Type, new org.netbeans.lib.awtextra.AbsoluteConstraints(580, 110, 152, 20));

        religion.setEditable(false);
        religion.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jPanel1.add(religion, new org.netbeans.lib.awtextra.AbsoluteConstraints(580, 170, 152, 20));

        MobileNo.setEditable(false);
        MobileNo.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jPanel1.add(MobileNo, new org.netbeans.lib.awtextra.AbsoluteConstraints(580, 230, 152, 20));

        Sec_Q.setEditable(false);
        Sec_Q.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jPanel1.add(Sec_Q, new org.netbeans.lib.awtextra.AbsoluteConstraints(580, 290, 152, 20));

        jButton2.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jButton2.setIcon(new javax.swing.ImageIcon("C:\\Users\\HP\\Downloads\\Banking_Management_System-master\\images\\icon_edit_new.gif")); // NOI18N
        jButton2.setText("Edit");
        jButton2.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });
        jPanel1.add(jButton2, new org.netbeans.lib.awtextra.AbsoluteConstraints(500, 480, 60, 20));

        jButton3.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jButton3.setIcon(new javax.swing.ImageIcon("C:\\Users\\HP\\Downloads\\Banking_Management_System-master\\images\\Save-icon.png")); // NOI18N
        jButton3.setText("Save");
        jButton3.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });
        jPanel1.add(jButton3, new org.netbeans.lib.awtextra.AbsoluteConstraints(620, 480, 70, 20));

        jLabel19.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel19.setText("Security Answer");
        jPanel1.add(jLabel19, new org.netbeans.lib.awtextra.AbsoluteConstraints(420, 350, 107, -1));

        Sec_A.setEditable(false);
        Sec_A.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jPanel1.add(Sec_A, new org.netbeans.lib.awtextra.AbsoluteConstraints(580, 350, 152, 20));

        jLabel2.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel2.setText("Account No.");
        jPanel1.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 50, 76, -1));

        AccountNo.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        AccountNo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                AccountNoActionPerformed(evt);
            }
        });
        jPanel1.add(AccountNo, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 50, 190, 20));

        jButton1.setIcon(new javax.swing.ImageIcon("C:\\Users\\HP\\Downloads\\Banking_Management_System-master\\images\\Eye-2-icon-1.png")); // NOI18N
        jButton1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        jPanel1.add(jButton1, new org.netbeans.lib.awtextra.AbsoluteConstraints(340, 50, 40, 20));

        jLabel27.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel27.setText("Occupation");
        jPanel1.add(jLabel27, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 410, -1, -1));

        Job.setEditable(false);
        Job.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jPanel1.add(Job, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 410, 190, 20));

        jLabel28.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel28.setText("Annual Income");
        jPanel1.add(jLabel28, new org.netbeans.lib.awtextra.AbsoluteConstraints(420, 410, -1, -1));

        income.setEditable(false);
        income.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jPanel1.add(income, new org.netbeans.lib.awtextra.AbsoluteConstraints(580, 410, 150, 20));

        jLabel29.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel29.setText("Client_ID");
        jPanel1.add(jLabel29, new org.netbeans.lib.awtextra.AbsoluteConstraints(420, 60, 110, -1));

        Client_ID.setEditable(false);
        Client_ID.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        Client_ID.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Client_IDActionPerformed(evt);
            }
        });
        jPanel1.add(Client_ID, new org.netbeans.lib.awtextra.AbsoluteConstraints(580, 60, 150, 20));

        jButton12.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jButton12.setIcon(new javax.swing.ImageIcon("C:\\Users\\HP\\Downloads\\Banking_Management_System-master\\images\\minus.gif")); // NOI18N
        jButton12.setText("Delete");
        jButton12.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jButton12.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton12ActionPerformed(evt);
            }
        });
        jPanel1.add(jButton12, new org.netbeans.lib.awtextra.AbsoluteConstraints(380, 480, 70, 20));

        jTabbedPane1.addTab("Profile", jPanel1);

        jPanel2.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 2));
        jPanel2.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel15.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel15.setText("Name");
        jPanel2.add(jLabel15, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 190, 78, -1));

        jLabel16.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel16.setText("Account No");
        jPanel2.add(jLabel16, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 130, 78, -1));

        jLabel17.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel17.setText("Current Balance");
        jPanel2.add(jLabel17, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 320, 111, -1));

        jLabel18.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel18.setText("Enter Amount");
        jPanel2.add(jLabel18, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 390, 120, -1));

        Accno.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jPanel2.add(Accno, new org.netbeans.lib.awtextra.AbsoluteConstraints(260, 130, 180, 20));

        name.setEditable(false);
        name.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jPanel2.add(name, new org.netbeans.lib.awtextra.AbsoluteConstraints(260, 190, 180, 20));

        Dep_amnt.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        Dep_amnt.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Dep_amntActionPerformed(evt);
            }
        });
        jPanel2.add(Dep_amnt, new org.netbeans.lib.awtextra.AbsoluteConstraints(260, 390, 180, 20));

        Bal.setEditable(false);
        Bal.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jPanel2.add(Bal, new org.netbeans.lib.awtextra.AbsoluteConstraints(260, 320, 180, 20));

        jButton4.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jButton4.setIcon(new javax.swing.ImageIcon("C:\\Users\\HP\\Downloads\\Banking_Management_System-master\\images\\search.gif")); // NOI18N
        jButton4.setText("Search");
        jButton4.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jButton4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton4ActionPerformed(evt);
            }
        });
        jPanel2.add(jButton4, new org.netbeans.lib.awtextra.AbsoluteConstraints(490, 130, 90, 20));

        Total_amnt.setEditable(false);
        Total_amnt.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jPanel2.add(Total_amnt, new org.netbeans.lib.awtextra.AbsoluteConstraints(260, 460, 180, 20));

        tot.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        tot.setIcon(new javax.swing.ImageIcon("C:\\Users\\HP\\Downloads\\Banking_Management_System-master\\images\\ok.gif")); // NOI18N
        tot.setText("Total");
        tot.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        tot.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                totActionPerformed(evt);
            }
        });
        jPanel2.add(tot, new org.netbeans.lib.awtextra.AbsoluteConstraints(480, 460, 99, -1));

        jButton6.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jButton6.setIcon(new javax.swing.ImageIcon("C:\\Users\\HP\\Downloads\\Banking_Management_System-master\\images\\ok.gif")); // NOI18N
        jButton6.setText("Transact");
        jButton6.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jButton6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton6ActionPerformed(evt);
            }
        });
        jPanel2.add(jButton6, new org.netbeans.lib.awtextra.AbsoluteConstraints(620, 510, 100, 20));

        jLabel11.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel11.setText("Type");
        jPanel2.add(jLabel11, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 250, 110, -1));

        type.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Credit", "Debit" }));
        type.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jPanel2.add(type, new org.netbeans.lib.awtextra.AbsoluteConstraints(260, 250, 180, 20));

        jLabel30.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel30.setText("Transaction_ID");
        jPanel2.add(jLabel30, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 70, 110, -1));

        Tran_ID.setEditable(false);
        Tran_ID.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jPanel2.add(Tran_ID, new org.netbeans.lib.awtextra.AbsoluteConstraints(260, 70, 180, 20));

        jTabbedPane1.addTab("Deposit/Withdrawal", jPanel2);

        jPanel3.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 2));
        jPanel3.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel21.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel21.setText("Name");
        jPanel3.add(jLabel21, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 210, 99, -1));

        jLabel22.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel22.setText("Account No");
        jPanel3.add(jLabel22, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 150, 99, -1));

        jLabel23.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel23.setText("Current Balance");
        jPanel3.add(jLabel23, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 270, 99, -1));

        jLabel24.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel24.setText("Transfer Amount");
        jPanel3.add(jLabel24, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 330, -1, -1));

        jLabel25.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel25.setText("Credit Account");
        jPanel3.add(jLabel25, new org.netbeans.lib.awtextra.AbsoluteConstraints(400, 150, 99, -1));

        uaccno.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jPanel3.add(uaccno, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 150, 120, 20));

        uname.setEditable(false);
        uname.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jPanel3.add(uname, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 210, 120, 20));

        ubal.setEditable(false);
        ubal.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jPanel3.add(ubal, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 270, 120, 20));

        jButton7.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jButton7.setIcon(new javax.swing.ImageIcon("C:\\Users\\HP\\Downloads\\Banking_Management_System-master\\images\\search.gif")); // NOI18N
        jButton7.setText("Search");
        jButton7.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jButton7.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton7ActionPerformed(evt);
            }
        });
        jPanel3.add(jButton7, new org.netbeans.lib.awtextra.AbsoluteConstraints(270, 150, 100, -1));

        Trans_amnt.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jPanel3.add(Trans_amnt, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 330, 120, 20));

        total.setEditable(false);
        total.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jPanel3.add(total, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 400, 120, 20));

        jButton8.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jButton8.setIcon(new javax.swing.ImageIcon("C:\\Users\\HP\\Downloads\\Banking_Management_System-master\\images\\ok.gif")); // NOI18N
        jButton8.setText("Total");
        jButton8.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jButton8.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton8ActionPerformed(evt);
            }
        });
        jPanel3.add(jButton8, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 400, 100, 20));

        Credit_amnt.setEditable(false);
        Credit_amnt.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        Credit_amnt.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Credit_amntActionPerformed(evt);
            }
        });
        jPanel3.add(Credit_amnt, new org.netbeans.lib.awtextra.AbsoluteConstraints(530, 270, 120, 20));

        Cre_total.setEditable(false);
        Cre_total.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jPanel3.add(Cre_total, new org.netbeans.lib.awtextra.AbsoluteConstraints(530, 330, 120, 20));

        jButton9.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jButton9.setIcon(new javax.swing.ImageIcon("C:\\Users\\HP\\Downloads\\Banking_Management_System-master\\images\\checked.png")); // NOI18N
        jButton9.setText("Show");
        jButton9.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jButton9.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton9ActionPerformed(evt);
            }
        });
        jPanel3.add(jButton9, new org.netbeans.lib.awtextra.AbsoluteConstraints(660, 330, 70, -1));

        jButton10.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jButton10.setIcon(new javax.swing.ImageIcon("C:\\Users\\HP\\Downloads\\Banking_Management_System-master\\images\\ok.gif")); // NOI18N
        jButton10.setText("Transfer");
        jButton10.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jButton10.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton10ActionPerformed(evt);
            }
        });
        jPanel3.add(jButton10, new org.netbeans.lib.awtextra.AbsoluteConstraints(560, 450, 90, -1));

        cname.setEditable(false);
        cname.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jPanel3.add(cname, new org.netbeans.lib.awtextra.AbsoluteConstraints(530, 210, 120, 20));

        jLabel20.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel20.setText("Name");
        jPanel3.add(jLabel20, new org.netbeans.lib.awtextra.AbsoluteConstraints(410, 210, 90, 20));

        jLabel26.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel26.setText("Current Balance");
        jPanel3.add(jLabel26, new org.netbeans.lib.awtextra.AbsoluteConstraints(410, 270, -1, -1));

        caccno.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jPanel3.add(caccno, new org.netbeans.lib.awtextra.AbsoluteConstraints(530, 150, 120, 20));

        jButton11.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jButton11.setIcon(new javax.swing.ImageIcon("C:\\Users\\HP\\Downloads\\Banking_Management_System-master\\images\\search.gif")); // NOI18N
        jButton11.setText("Search");
        jButton11.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jButton11.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton11ActionPerformed(evt);
            }
        });
        jPanel3.add(jButton11, new org.netbeans.lib.awtextra.AbsoluteConstraints(660, 150, 70, 20));

        Tran_ID1.setEditable(false);
        Tran_ID1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        Tran_ID1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Tran_ID1ActionPerformed(evt);
            }
        });
        jPanel3.add(Tran_ID1, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 90, 130, 20));

        jLabel31.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel31.setText("Transaction_ID");
        jPanel3.add(jLabel31, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 90, 110, -1));

        Tran_ID2.setEditable(false);
        Tran_ID2.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jPanel3.add(Tran_ID2, new org.netbeans.lib.awtextra.AbsoluteConstraints(530, 90, 120, 20));

        jLabel32.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel32.setText("Transaction_ID");
        jPanel3.add(jLabel32, new org.netbeans.lib.awtextra.AbsoluteConstraints(400, 90, 110, -1));

        jTabbedPane1.addTab("Transfer", jPanel3);

        jPanel6.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 2));
        jPanel6.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel14.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel14.setText("Enter Account No.");
        jPanel6.add(jLabel14, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 60, 143, -1));

        tacno.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jPanel6.add(tacno, new org.netbeans.lib.awtextra.AbsoluteConstraints(350, 60, 160, 20));

        jButton5.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jButton5.setIcon(new javax.swing.ImageIcon("C:\\Users\\HP\\Downloads\\Banking_Management_System-master\\images\\ok.gif")); // NOI18N
        jButton5.setText("Display");
        jButton5.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jButton5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton5ActionPerformed(evt);
            }
        });
        jPanel6.add(jButton5, new org.netbeans.lib.awtextra.AbsoluteConstraints(540, 60, 80, 20));

        jTable2.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jTable2.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane2.setViewportView(jTable2);

        jPanel6.add(jScrollPane2, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 120, 680, 400));

        jTabbedPane1.addTab("Transaction", jPanel6);

        jPanel7.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 2));
        jPanel7.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel33.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel33.setText("Name");
        jPanel7.add(jLabel33, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 190, 106, -1));

        jLabel34.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel34.setText("Account No");
        jPanel7.add(jLabel34, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 130, 122, -1));

        jLabel37.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel37.setText("Available Balance");
        jPanel7.add(jLabel37, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 260, -1, -1));

        baccno.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jPanel7.add(baccno, new org.netbeans.lib.awtextra.AbsoluteConstraints(360, 130, 175, 20));

        bname.setEditable(false);
        bname.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jPanel7.add(bname, new org.netbeans.lib.awtextra.AbsoluteConstraints(360, 190, 175, 20));

        bbal.setEditable(false);
        bbal.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jPanel7.add(bbal, new org.netbeans.lib.awtextra.AbsoluteConstraints(360, 260, 175, 20));

        jButton14.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jButton14.setIcon(new javax.swing.ImageIcon("C:\\Users\\HP\\Downloads\\Banking_Management_System-master\\images\\search.gif")); // NOI18N
        jButton14.setText("Search");
        jButton14.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jButton14.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton14ActionPerformed(evt);
            }
        });
        jPanel7.add(jButton14, new org.netbeans.lib.awtextra.AbsoluteConstraints(580, 130, 80, -1));

        jTabbedPane1.addTab("View Balance", jPanel7);

        jPanel5.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 2));
        jPanel5.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jTable1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane1.setViewportView(jTable1);

        jPanel5.add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(25, 20, 750, 510));

        jTabbedPane1.addTab("Customer List", jPanel5);

        getContentPane().add(jTabbedPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 150, 750, 590));

        newacc.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        newacc.setIcon(new javax.swing.ImageIcon("C:\\Users\\HP\\Downloads\\Banking_Management_System-master\\images\\addusericon.png")); // NOI18N
        newacc.setText("New Account");
        newacc.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                newaccActionPerformed(evt);
            }
        });
        getContentPane().add(newacc, new org.netbeans.lib.awtextra.AbsoluteConstraints(610, 90, 144, -1));

        jLabel36.setIcon(new javax.swing.ImageIcon("C:\\Users\\HP\\Downloads\\Banking_Management_System-master\\images\\bank-system-tile.png")); // NOI18N
        getContentPane().add(jLabel36, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, -50, 840, 840));

        jLabel9.setText("jLabel9");
        getContentPane().add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(3, 0, 780, 630));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void dteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_dteActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_dteActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        Nationality.setEditable(true);
        Gender.setEditable(true);
        Address.setEditable(true);
        religion.setEditable(true);
        MobileNo.setEditable(true);
        Sec_Q.setEditable(true);
        Sec_A.setEditable(true);
        Job.setEditable(true);
        income.setEditable(true);
    }//GEN-LAST:event_jButton2ActionPerformed

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
        try{
            String value1=Nationality.getText();
            String value2=Gender.getText();
            String value3=Address.getText();
            String value4=religion.getText();
            String value5=MobileNo.getText();
            String value6=Sec_Q.getText();
            String value7=Sec_A.getText();
            String value8=Client_ID.getText();
            String value9=Job.getText();
            String value10=income.getText();
            String sql="update CLIENT set NATIONALITY='"+value1+"',GENDER='"+value2+"',ADDRESS='"+value3+"',RELIGION='"+value4+"',MOB_NO='"+value5+"',SEC_Q='"+value6+"',SEC_A='"+value7+"',OCCUPATION='"+value9+"',ANN_INCOME='"+value10+"'where CLIENT_ID='"+value8+"'";
            pst=conn.prepareStatement(sql);
            pst.execute();
            JOptionPane.showMessageDialog(null, "Profile Updated");
        }catch(HeadlessException | SQLException e){
            //JOptionPane.showMessageDialog(null, e);
        }
    }//GEN-LAST:event_jButton3ActionPerformed

    private void AccountNoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_AccountNoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_AccountNoActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        try{
            String ID = AccountNo.getText();
            String sql="select A.ACC_TYPE,C.NAME,C.DOB,C.NATIONALITY,C.GENDER,C.ADDRESS,C.OCCUPATION,C.CLIENT_ID,C.RELIGION,C.MOB_NO,C.SEC_Q,C.SEC_A,C.ANN_INCOME from CLIENT C,ACCOUNT A where A.CLIENT_ID=C.CLIENT_ID AND A.ACCOUNTNO='"+ID+"'";
            PreparedStatement stmt=conn.prepareStatement(sql);
            ResultSet res = stmt.executeQuery();
            if(res.next()){
                String add1=res.getString("NAME");
                Name.setText(add1);
                String add3=res.getString("DOB");
                DOB.setText(add3);
                String add4=res.getString("ACC_TYPE");
                Account_Type.setText(add4);
                String add5=res.getString("NATIONALITY");
                Nationality.setText(add5);
                String add6=res.getString("RELIGION");
                religion.setText(add6);
                String add7=res.getString("GENDER");
                Gender.setText(add7);
                String add8=res.getString("MOB_NO");
                MobileNo.setText(add8);
                String add9=res.getString("ADDRESS");
                Address.setText(add9);
                String add10=res.getString("SEC_Q");
                Sec_Q.setText(add10);
                String add11=res.getString("SEC_A");
                Sec_A.setText(add11);
                String add12=res.getString("CLIENT_ID");
                Client_ID.setText(add12);
                String add13=res.getString("OCCUPATION");
                Job.setText(add13);
                String add14=res.getString("ANN_INCOME");
                income.setText(add14);

                res.close();
                stmt.close();
            }
            else{
                JOptionPane.showMessageDialog(null, "Enter Correct Account No.");
            }

        }catch(HeadlessException | SQLException e){
            //JOptionPane.showMessageDialog(null, e);
        }finally{
            try{
                rs.close();
                pst.close();
            }catch(SQLException e){

            }
        }
    }//GEN-LAST:event_jButton1ActionPerformed

    private void Client_IDActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Client_IDActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_Client_IDActionPerformed

    private void jButton12ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton12ActionPerformed

        int a=JOptionPane.showConfirmDialog((Component)null,"Do you want to delete?","DELETE",JOptionPane.YES_NO_OPTION);
        if(a==0){
            String acno=AccountNo.getText();
            String sql="DELETE FROM ACCOUNT WHERE ACCOUNTNO='"+acno+"'";
            try{
                pst=conn.prepareStatement(sql);
                pst.execute();
                JOptionPane.showMessageDialog(null,"Deleted Successfully");
                AccountNo.setText("");
                DOB.setText("");
                Client_ID.setText("");
                Address.setText("");
                Sec_Q.setText("");
                Name.setText("");
                Gender.setText("");
                religion.setText("");
                Account_Type.setText("");
                Nationality.setText("");
                MobileNo.setText("");
                Sec_A.setText("");
                Job.setText("");
                income.setText("");
            }
            catch(HeadlessException | SQLException e){

            }finally{
                try{
                    pst.close();
                    rs.close();
                }catch(SQLException e){}
            }
        }
    }//GEN-LAST:event_jButton12ActionPerformed

    private void jButton4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton4ActionPerformed

        try{
            String tnO=Accno.getText();
            String sql="select C.NAME,A.AMOUNT from ACCOUNT A,CLIENT C where C.CLIENT_ID=A.CLIENT_ID AND A.ACCOUNTNO='"+tnO+"'";
            PreparedStatement pt=conn.prepareStatement(sql);
            ResultSet rts=pt.executeQuery();
            if(rts.next()){
                String add1=rts.getString("NAME");
                name.setText(add1);
                String add2=rts.getString("AMOUNT");
                Bal.setText(add2);
                rts.close();
                pt.close();
            }
            else{
                JOptionPane.showMessageDialog(null, "Enter Correct Account No.");
            }

        }catch(HeadlessException | SQLException e){
            //JOptionPane.showMessageDialog(null, e);
        }finally{
            try{
                rs.close();
                pst.close();
            }catch(SQLException e){

            }
        }
    }//GEN-LAST:event_jButton4ActionPerformed

    private void totActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_totActionPerformed
        try{
            String a1=Bal.getText();
            String a2=Dep_amnt.getText();
            String b1=type.getItemAt(type.getSelectedIndex());

            if(b1.equals("Debit"))
            {
                int bal=Integer.parseInt(a1)-Integer.parseInt(a2);
                String deb=String.valueOf(bal);
                Total_amnt.setText(deb);
            }
            else
            {
                int sum=Integer.parseInt(a1)+Integer.parseInt(a2);
                String sum1=String.valueOf(sum);
                Total_amnt.setText(sum1);
            }

        }catch(NumberFormatException e){
            //JOptionPane.showMessageDialog(null, e);
        }
    }//GEN-LAST:event_totActionPerformed

    private void jButton6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton6ActionPerformed
        String value=Tran_ID.getText();
        String value1=Accno.getText();
        String value2=Total_amnt.getText();
        String b1=type.getItemAt(type.getSelectedIndex());
        String Dep=Dep_amnt.getText();
        String value3=dte.getText();
        try{

            String sql="insert into Transactions values(?,?,?,?,?,?)";
            PreparedStatement stmt=conn.prepareStatement(sql);
            stmt.setString(1,value);
            stmt.setString(2,value1);
            stmt.setString(3,b1);
            stmt.setString(4,value2);
            stmt.setString(5,Dep);
            stmt.setString(6,value3);
            stmt.execute();

            //JOptionPane.showMessageDialog(null," sucessfull");

            String qry="UPDATE ACCOUNT set AMOUNT='"+value2+"' where ACCOUNTNO='"+value1+"' ";
            PreparedStatement pstmt=conn.prepareStatement(qry);
            pstmt.executeUpdate();

            JOptionPane.showMessageDialog(null, "Transaction Sucessfull");
            Accno.setText("");
            name.setText("");
            Accno.setText("");
            Bal.setText("");
            Dep_amnt.setText("");
            Total_amnt.setText("");

        }catch(SQLException e){
            // JOptionPane.showMessageDialog(null, e);
        }
        RandomID();
    }//GEN-LAST:event_jButton6ActionPerformed

    private void jButton7ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton7ActionPerformed

        try{
            String trno=uaccno.getText();
            String sql="select C.NAME,A.AMOUNT from ACCOUNT A,CLIENT C where C.CLIENT_ID=A.CLIENT_ID AND A.ACCOUNTNO='"+trno+"'";
            PreparedStatement pr=conn.prepareStatement(sql);
            ResultSet re=pr.executeQuery();
            if(re.next()){
                String add1=re.getString("NAME");
                uname.setText(add1);
                String add3=re.getString("AMOUNT");
                ubal.setText(add3);
                re.close();
                pr.close();
            }
            else{
                JOptionPane.showMessageDialog(null, "Enter Correct Account No.");
            }
        }catch(HeadlessException | SQLException e){
            // JOptionPane.showMessageDialog(null, e);
        }finally{
            try{
                rs.close();
                pst.close();
            }catch(SQLException e){

            }
        }
    }//GEN-LAST:event_jButton7ActionPerformed

    private void jButton8ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton8ActionPerformed
        try{
            String a1=ubal.getText();
            String a2=Trans_amnt.getText();
            int sum=Integer.parseInt(a1)-Integer.parseInt(a2);
            String sum1=String.valueOf(sum);
            total.setText(sum1);

        }catch(NumberFormatException e){
            // JOptionPane.showMessageDialog(null, e);
        }
    }//GEN-LAST:event_jButton8ActionPerformed

    private void Credit_amntActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Credit_amntActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_Credit_amntActionPerformed

    private void jButton9ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton9ActionPerformed
        try{
            String a1=Trans_amnt.getText();
            String a2=Credit_amnt.getText();
            int sum=Integer.parseInt(a1)+Integer.parseInt(a2);
            String sum1=String.valueOf(sum);
            Cre_total.setText(sum1);

        }catch(NumberFormatException e){
            // JOptionPane.showMessageDialog(null, e);
        }
    }//GEN-LAST:event_jButton9ActionPerformed

    private void jButton10ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton10ActionPerformed
        TransferD();
        TransferC();
        RandomID2();
        RandomID1();

    }//GEN-LAST:event_jButton10ActionPerformed

    
    public void TransferC(){
        
         try
         {
             String sql1="insert into Transactions values(?,?,?,?,?,?)";
        String value2=caccno.getText();
        String value3=Cre_total.getText();

         
                pst=conn.prepareStatement(sql1);
                pst.setString(1,Tran_ID2.getText());
                pst.setString(2,caccno.getText());
                pst.setString(4,Cre_total.getText());
                pst.setString(5,Trans_amnt.getText());
                pst.setString(3,"Credit");
                pst.setString(6,dte.getText());
                pst.executeUpdate();
     
         
         String sql2="update ACCOUNT set AMOUNT='"+value3+"' where ACCOUNTNO='"+value2+"'";
         pst=conn.prepareStatement(sql2);
         pst.executeUpdate();
         JOptionPane.showMessageDialog(null, "Succesfully Transfered");
         caccno.setText("");
         Cre_total.setText("");
         Trans_amnt.setText("");
         
     }
         catch(HeadlessException | SQLException e){
       
     }
         
     }
 
 public void TransferD(){
      try{ 
     
     String sql1="insert into Transactions values(?,?,?,?,?,?)";
     
        pst=conn.prepareStatement(sql1);
        pst.setString(1,Tran_ID1.getText());
        pst.setString(2,uaccno.getText());
        pst.setString(4,total.getText());
        pst.setString(5,Trans_amnt.getText());
        pst.setString(3,"Debit");
        pst.setString(6,dte.getText());
        pst.executeUpdate();
        
     
         String value2=uaccno.getText();
         String value3=total.getText();
        String sql="update ACCOUNT set AMOUNT='"+value3+"' where ACCOUNTNO='"+value2+"'";
        pst=conn.prepareStatement(sql);
        pst.executeUpdate();
        
        uaccno.setText("");
        total.setText("");
 
     }catch(SQLException e){
         //JOptionPane.showMessageDialog(null, e);
     }
     
 }
 
    private void jButton11ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton11ActionPerformed
        try{
            String trno=caccno.getText();
            String sql="select C.NAME,A.AMOUNT from ACCOUNT A,CLIENT C where C.CLIENT_ID=A.CLIENT_ID AND A.ACCOUNTNO='"+trno+"'";
            PreparedStatement pr=conn.prepareStatement(sql);
            ResultSet re=pr.executeQuery();
            if(re.next()){
                String add1=re.getString("NAME");
                cname.setText(add1);
                String add3=re.getString("AMOUNT");
                Credit_amnt.setText(add3);
                re.close();
                pr.close();
            }
            else{
                JOptionPane.showMessageDialog(null, "Enter Correct Account No.");
            }
        }catch(HeadlessException | SQLException e){
            // JOptionPane.showMessageDialog(null, e);
        }finally{
            try{
                rs.close();
                pst.close();
            }catch(SQLException e){

            }
        }
    }//GEN-LAST:event_jButton11ActionPerformed

    private void Tran_ID1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Tran_ID1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_Tran_ID1ActionPerformed

    private void jButton14ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton14ActionPerformed

        try{
            String vno=baccno.getText();
            String sql="SELECT NAME,AMOUNT FROM CLIENT C,ACCOUNT A WHERE A.CLIENT_ID=C.CLIENT_ID AND A.ACCOUNTNO='"+vno+"'";
            PreparedStatement ps=conn.prepareStatement(sql);
            ResultSet s=ps.executeQuery();
            if(s.next()){
                String add1=s.getString("NAME");
                bname.setText(add1);
                String add2=s.getString("AMOUNT");
                bbal.setText(add2);

            }
            else{
                JOptionPane.showMessageDialog(null, "Enter Correct Account No.");
            }
        }catch(HeadlessException | SQLException e){
            //JOptionPane.showMessageDialog(null, e);
        }
    }//GEN-LAST:event_jButton14ActionPerformed

    private void jButton5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton5ActionPerformed
        
        try{
            String str=tacno.getText();
            String sql="select * from Transactions where ACCOUNTNO='"+str+"' ";
            pst=conn.prepareStatement(sql);
            ResultSet rss=pst.executeQuery();
            jTable2.setModel(DbUtils.resultSetToTableModel(rss));
        }
        catch(SQLException e){}
    }//GEN-LAST:event_jButton5ActionPerformed

    private void newaccActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_newaccActionPerformed
        setVisible(false);
        Account ob=new Account();
        ob.setVisible(true);
    }//GEN-LAST:event_newaccActionPerformed

    private void Dep_amntActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Dep_amntActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_Dep_amntActionPerformed

    public static void main(String args[]) {
    
        java.awt.EventQueue.invokeLater(new Runnable() {
            @Override
            public void run() {
                new MyPage().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextField Accno;
    private javax.swing.JTextField AccountNo;
    private javax.swing.JTextField Account_Type;
    private javax.swing.JTextField Address;
    private javax.swing.JTextField Bal;
    private javax.swing.JTextField Client_ID;
    private javax.swing.JTextField Cre_total;
    private javax.swing.JTextField Credit_amnt;
    private javax.swing.JTextField DOB;
    private javax.swing.JTextField Dep_amnt;
    private javax.swing.JTextField Gender;
    private javax.swing.JTextField Job;
    private javax.swing.JTextField MobileNo;
    private javax.swing.JTextField Name;
    private javax.swing.JTextField Nationality;
    private javax.swing.JLabel Religion;
    private javax.swing.JTextField Sec_A;
    private javax.swing.JTextField Sec_Q;
    private javax.swing.JTextField Total_amnt;
    private javax.swing.JTextField Tran_ID;
    private javax.swing.JTextField Tran_ID1;
    private javax.swing.JTextField Tran_ID2;
    private javax.swing.JTextField Trans_amnt;
    private javax.swing.JTextField baccno;
    private javax.swing.JTextField bbal;
    private javax.swing.JTextField bname;
    private javax.swing.JTextField caccno;
    private javax.swing.JTextField cname;
    private javax.swing.JTextField dte;
    private javax.swing.JTextField income;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton10;
    private javax.swing.JButton jButton11;
    private javax.swing.JButton jButton12;
    private javax.swing.JButton jButton14;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton4;
    private javax.swing.JButton jButton5;
    private javax.swing.JButton jButton6;
    private javax.swing.JButton jButton7;
    private javax.swing.JButton jButton8;
    private javax.swing.JButton jButton9;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel20;
    private javax.swing.JLabel jLabel21;
    private javax.swing.JLabel jLabel22;
    private javax.swing.JLabel jLabel23;
    private javax.swing.JLabel jLabel24;
    private javax.swing.JLabel jLabel25;
    private javax.swing.JLabel jLabel26;
    private javax.swing.JLabel jLabel27;
    private javax.swing.JLabel jLabel28;
    private javax.swing.JLabel jLabel29;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel30;
    private javax.swing.JLabel jLabel31;
    private javax.swing.JLabel jLabel32;
    private javax.swing.JLabel jLabel33;
    private javax.swing.JLabel jLabel34;
    private javax.swing.JLabel jLabel36;
    private javax.swing.JLabel jLabel37;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JPanel jPanel7;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTabbedPane jTabbedPane1;
    private javax.swing.JTable jTable1;
    private javax.swing.JTable jTable2;
    private javax.swing.JTextField name;
    private javax.swing.JButton newacc;
    private javax.swing.JTextField religion;
    private javax.swing.JTextField tacno;
    private javax.swing.JButton tot;
    private javax.swing.JTextField total;
    private javax.swing.JComboBox<String> type;
    private javax.swing.JTextField uaccno;
    private javax.swing.JTextField ubal;
    private javax.swing.JTextField uname;
    // End of variables declaration//GEN-END:variables
}
